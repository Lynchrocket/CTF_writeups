# CTF题目 June. 21st 2021

## Web: POST Practice

This website requires authentication, via POST. However, it seems as if someone has defaced our site. Maybe there is still some way to authenticate?

http://165.227.106.113/post.php

```bash
curl -d "username=admin&password=71urlkufpsdnlkadsf" -X POST http://165.227.106.113/post.php
flag{p0st_d4t4_4ll_d4y}
```



## Crypto: Base 2 2 the 6

There are so many different ways of encoding and decoding information nowadays... One of them will work!

Q1RGe0ZsYWdneVdhZ2d5UmFnZ3l9

```bash
From Base64
CTF{FlaggyWaggyRaggy}
```



## Crypto: Morse Code

..-. .-.. .- --. ... .- -- ..- . .-.. -- --- .-. ... . .. ... -.-. --- --- .-.. -... -.-- - .... . .-- .- -.-- .. .-.. .. -.- . -.-. .... . . ...

```bash
From Morse Code
FLAGSAMUELMORSEISCOOLBYTHEWAYILIKECHEES
```



## Forensics: WOW.... So Meta

This photo was taken by our target. See what you can find out about him from it.

https://mega.nz/#!ifA2QAwQ!WF-S-MtWHugj8lx1QanGG7V91R-S1ng7dDRSV25iFbk

```bash
strings 3UWLBAUCb9Z2.jpg
flag{EEe_x_I_FFf}
```



## Misc: QR Code

Do you remember something known as QR Code? Simple. Here for you :

https://mega.nz/#!eGYlFa5Z!8mbiqg3kosk93qJCP-DBxIilHH2rf7iIVY-kpwyrx-0

```bash
https://webqr.com/index.html
c3ludCB2ZiA6IGEwX29icWxfczBldHJnX2RlX3BicXI=
From Base64
synt vf : a0_obql_s0etrg_de_pbqr
ROT13
flag is : n0_body_f0rget_qr_code
```

