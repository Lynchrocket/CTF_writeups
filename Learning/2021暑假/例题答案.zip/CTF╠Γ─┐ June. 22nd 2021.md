# CTF题目 June. 22nd 2021

## Chalkboard

Solve the equations embedded in the jpeg to find the flag.

https://ctflearn.com/challenge/download/972

Flag format: `CTFlearn{**************}`

```bash
strings math.jpg
CTFlearn{I_Like_Math_x_y}
x=2, y=5
CTFlearn{I_Like_Math_2_5}
```



## Time Traveller

Let's take a trip to nasa.gov on December 31, 1996. If you can tell me what email NASA listed on their website, I'll provide you with 10 points.

Format: `CTFlearn{email}`

```bash
https://web.archive.org/web/19961231235847/https://www.nasa.gov/
today@nasa.gov
```



## Gobustme 👻

Some ghosts made this site 👻, it's a little spooky but there's a bunch of stuff hidden around.

[gobustme.ctflearn.com](https://gobustme.ctflearn.com/)

Flag format: `CTFlearn{************}`

```bash
gobuster -u https://gobustme.ctflearn.com/hide/ -w /usr/share/wordlists/common.txt
https://gobustme.ctflearn.com/hide/
CTFlearn{gh0sbu5t3rs_4ever}
```



## Raspberry

Raspberry Reversing Challenge

This 20 point challenge is specifically created for people new to reversing and assembly language programming. You can solve this first using Ghidra or IDA if you want to just get the flag and solve the challenge.

If you want to start learning some assembly language programming to build the skills needed to solve some of the more difficult reversing challenges, then step through the debugger and examine the registers to see how each each letter in the flag is determined to be correct or incorrect.

This challenge gives people new to assembly language programming the chance to learn mov, xor, cmp, jmp, call, add, sub, mul, div and shl instructions when they operate on a single byte (for most of the letters in the flag).

Good luck and have fun!

https://ctflearn.com/challenge/download/1080

Flag format: `CTFlearn{*******}`

```bash
cmp     bl, 0x43

cmp     bl, 0x54

cmp     bl, 0x46

add     rbx, 0xab
cmp     rbx, 0x117

cmp     rbx, 0x65

xor     rbx, 0xab
cmp     rbx, 0xca

mov     ebx, 0xbaadf00d
mul     rbx
mov     rbx, rax
mov     rax, 0x532174e5ca
cmp     rax, rbx

mov     bl, 0x3
div     rbx
cmp     rax, 0x24
cmp     rdx, 0x2

cmp     bl, 0x7b

cmp     al, 0x2b

xor     al, 0xcb
cmp     al, 0x8d

add     rax, 0x22
cmp     rax, 0x94

sub     rax, 0x22
cmp     rax, 0x53

mov     ebx, 0x15
mul     rbx
cmp     rax, 0x89d

mov     ebx, 0x15
div     rbx
cmp     rax, 0x5
cmp     rdx, 0xb

shl     rax, 0x1
cmp     rax, 0x62

cmp     bl, 0x32

shl     rax, 0x4
cmp     rax, 0x330

cmp     rax, 0x7d

43 54 46 6c 65 61 72 6e 7b 2b 46 72 75 69 74 31 32 33 7d
CTFlearn{+Fruit123}
```

