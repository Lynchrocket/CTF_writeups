# CTF题目 June. 24th 2021

## [Easy] [Forensics] GandalfTheWise

Extract the flag from the Gandalf.jpg file. You may need to write a quick script to solve this.

https://ctflearn.com/challenge/download/936

```bash
CTFlearn{xor_is_your_friend}
xD6kfO2UrE5SnLQ6WgESK4kvD/Y/rDJPXNU45k/p
h2riEIj13iAp29VUPmB+TadtZppdw3AuO7JRiDyU
CTFlearn{Gandalf.BilboBaggins}
```



## [Easy] [Forensics] Binwalk

Here is a file with another file hidden inside it. Can you extract it?

https://mega.nz/#!qbpUTYiK!-deNdQJxsQS8bTSMxeUOtpEclCI-zpK7tbJiKV0tXYY

```bash
binwalk --dd='.*' PurpleThing.jpeg
ABCTF{b1nw4lk_is_us3ful}
```



## [Medium] [Web] Don't Bump Your Head(er)

Try to bypass my security measure on this site!

http://165.227.106.113/header.php

```bash
Sorry, it seems as if your user agent is not correct, in order to access this website. The one you supplied is: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.106 Safari/537.36
<!-- Sup3rS3cr3tAg3nt  -->
Sorry, it seems as if you did not just come from the site, "awesomesauce.com".

GET /header.php HTTP/1.1
Host: 165.227.106.113
Referer: awesomesauce.com
DNT: 1
Upgrade-Insecure-Requests: 1
User-Agent: Sup3rS3cr3tAg3nt
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7,zh-TW;q=0.6
Connection: close

Here is your flag: flag{did_this_m3ss_with_y0ur_h34d}
```



## [Medium] [Crypto] BruXOR

There is a technique called bruteforce.

Message: q{vpln'bH_varHuebcrqxetrHOXEj

No key! Just brute .. brute .. brute ... :D

```bash
Key = 17: flag{y0u_Have_bruteforce_XOR}
```



## [Medium] [Miscellaneous] What could this be?

It seems like someone really likes special characters… Or could it mean something more?

https://mega.nz/#!SDQkUYQZ!b1Fu7iZ_wGiNX0aOjez95_74TYDCnLb3YSQfRzs0J-o

```bash
JavaScript
flag{5uch_j4v4_5crip7_much_w0w}
```

